import { useEffect, useRef, useState } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import './Prizes.css'

gsap.registerPlugin(ScrollTrigger)

/* ─── Retro Trophy SVGs ──────────────────────────────────────── */
function RetroTrophy({ rank }) {
  const themes = {
    1: {
      metal: '#f7d279',
      metalDark: '#b8861e',
      shadow: '#664708',
      shine: '#fff3cd',
      glow: 'rgba(247, 210, 121, 0.45)',
    },
    2: {
      metal: '#dcdde3',
      metalDark: '#8b8e9b',
      shadow: '#494c59',
      shine: '#ffffff',
      glow: 'rgba(220, 221, 227, 0.35)',
    },
    3: {
      metal: '#e09867',
      metalDark: '#99542a',
      shadow: '#592c10',
      shine: '#ffe3d1',
      glow: 'rgba(224, 152, 103, 0.35)',
    },
  }[rank]

  return (
    <svg viewBox="0 0 72 82" className="retro-trophy-svg" aria-hidden="true">
      <defs>
        <linearGradient id={`trophy-grad-${rank}`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor={themes.shine} />
          <stop offset="35%" stopColor={themes.metal} />
          <stop offset="75%" stopColor={themes.metalDark} />
          <stop offset="100%" stopColor={themes.shadow} />
        </linearGradient>
      </defs>
      {/* Cup bowl */}
      <path
        d="M14 6 H58 V36 C58 48 48 56 36 56 C24 56 14 48 14 36 Z"
        fill={`url(#trophy-grad-${rank})`}
        stroke="#12151b"
        strokeWidth="2.5"
      />
      {/* Left handle */}
      <path
        d="M14 14 H6 C3 14 1 17 1 20 V26 C1 34 8 40 16 40 H17"
        fill="none"
        stroke={themes.metal}
        strokeWidth="3.5"
        strokeLinecap="round"
      />
      {/* Right handle */}
      <path
        d="M58 14 H66 C69 14 71 17 71 20 V26 C71 34 64 40 56 40 H55"
        fill="none"
        stroke={themes.metal}
        strokeWidth="3.5"
        strokeLinecap="round"
      />
      {/* Cup inner lip */}
      <ellipse cx="36" cy="8" rx="21" ry="4" fill={themes.shine} opacity="0.6" />
      {/* Star emblem on cup */}
      <polygon
        points="36,18 38.5,25 46,25 40,29.5 42.5,37 36,32.5 29.5,37 32,29.5 26,25 33.5,25"
        fill="#ffffff"
        opacity="0.85"
      />
      {/* Stem */}
      <rect x="31" y="56" width="10" height="12" fill={themes.metalDark} stroke="#12151b" strokeWidth="2" />
      {/* Base tier 1 */}
      <polygon points="22,68 50,68 54,74 18,74" fill={themes.metal} stroke="#12151b" strokeWidth="2" />
      {/* Base tier 2 */}
      <rect x="14" y="74" width="44" height="6" rx="2" fill={themes.shadow} stroke="#12151b" strokeWidth="2" />
    </svg>
  )
}

/* ─── Main Podium Prizes ─────────────────────────────────────── */
const MAIN_PRIZES = [
  {
    rank: 1,
    title: '1st Place',
    amount: 200000,
    formatted: '₹2,00,000',
    subtitle: 'GRAND CHAMPION',
    status: '● PODIUM // WINNER',
    code: 'SYS-RW-01',
    perks: [
      '₹2,00,000 Cash Prize',
      'Exclusive Gold Trophy & Citation',
      'Premium Swag & Goodies Kit',
      'Direct Fast-Track Interview Access',
      'Cloud Credits & Developer Perks',
    ],
  },
  {
    rank: 2,
    title: '2nd Place',
    amount: 100000,
    formatted: '₹1,00,000',
    subtitle: 'FIRST RUNNER UP',
    status: '● PODIUM // RUNNER UP',
    code: 'SYS-RW-02',
    perks: [
      '₹1,00,000 Cash Prize',
      'Silver Trophy & Citation',
      'Participant Swag & Goodies Kit',
      'Partner Fast-Track Review Access',
      'Cloud Credits & Developer Perks',
    ],
  },
  {
    rank: 3,
    title: '3rd Place',
    amount: 50000,
    formatted: '₹50,000',
    subtitle: 'SECOND RUNNER UP',
    status: '● PODIUM // 2ND RUNNER UP',
    code: 'SYS-RW-03',
    perks: [
      '₹50,000 Cash Prize',
      'Bronze Trophy & Citation',
      'Participant Swag & Goodies Kit',
      'Mentorship Network Access',
      'Cloud Credits & Developer Perks',
    ],
  },
]

/* ─── Special Track Categories ───────────────────────────────── */
const SPECIAL_BOUNTIES = [
  {
    tag: 'CATEGORY 01',
    name: 'Best All-Women Team',
    amount: '₹10,000',
    perk: 'Cash Bounty + Special Trophy & Goodies',
    icon: '⚡',
  },
  {
    tag: 'CATEGORY 02',
    name: 'Best Freshers Squad',
    amount: '₹10,000',
    perk: 'Cash Bounty + Rising Star Certificate',
    icon: '✦',
  },
  {
    tag: 'CATEGORY 03',
    name: 'Best AI / Autonomous Hack',
    amount: '₹15,000',
    perk: 'Special Sponsor Bounty + API Credits',
    icon: '◈',
  },
  {
    tag: 'CATEGORY 04',
    name: 'Most Innovative Web3 Hack',
    amount: '₹15,000',
    perk: 'Web3 Grant Pool + Protocol Goodies',
    icon: '☵',
  },
]

function formatNumberINR(val, target) {
  if (val >= target) {
    if (target === 200000) return '₹2,00,000'
    if (target === 100000) return '₹1,00,000'
    return '₹50,000'
  }
  return '₹' + Math.floor(val).toLocaleString('en-IN')
}

export default function Prizes({ onNavigate }) {
  const sectionRef = useRef(null)
  const [counters, setCounters] = useState([0, 0, 0])

  useEffect(() => {
    const sect = sectionRef.current
    if (!sect) return undefined
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches

    const ctx = gsap.context(() => {
      // 1. Entrance reveals
      gsap.fromTo(
        '.prizes-hero-block',
        { autoAlpha: 0, y: 24 },
        {
          autoAlpha: 1,
          y: 0,
          duration: 0.7,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sect,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          },
        }
      )

      gsap.fromTo(
        '.fullscreen-prize-card',
        { autoAlpha: 0, y: 35 },
        {
          autoAlpha: 1,
          y: 0,
          duration: 0.65,
          stagger: 0.12,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: '.prizes-cards-container',
            start: 'top 88%',
            toggleActions: 'play none none reverse',
          },
        }
      )

      gsap.fromTo(
        '.special-bounties-shelf',
        { autoAlpha: 0, y: 24 },
        {
          autoAlpha: 1,
          y: 0,
          duration: 0.65,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: '.special-bounties-shelf',
            start: 'top 90%',
            toggleActions: 'play none none reverse',
          },
        }
      )

      // 2. Prize Counter Tickers
      MAIN_PRIZES.forEach((p, i) => {
        const obj = { val: 0 }
        ScrollTrigger.create({
          trigger: '.prizes-cards-container',
          start: 'top 88%',
          once: true,
          onEnter: () => {
            gsap.to(obj, {
              val: p.amount,
              duration: reduced ? 0.1 : 1.8,
              ease: 'power3.out',
              onUpdate: () => {
                setCounters((prev) => {
                  const next = [...prev]
                  next[i] = obj.val
                  return next
                })
              },
            })
          },
        })
      })
    }, sect)

    return () => ctx.revert()
  }, [])

  return (
    <section ref={sectionRef} className="retro-prizes-fullscreen-section" id="prizes">
      {/* Main Expansive Content Container */}
      <div className="prizes-fullwidth-wrapper">
        {/* ── HEADER BLOCK ─────────────────────────────────────────── */}
        <div className="prizes-hero-block">
          <div className="prizes-headline-column">
            <div className="section-flow-eyebrow">
              <span className="flow-num">03</span>
              <span className="flow-dash">—</span>
              <span className="flow-label">PRIZES &amp; BOUNTIES</span>
            </div>

            <h2 className="prizes-main-title">
              RECOGNITION <br />
              <span className="prizes-title-amber">FOR THE BOLD.</span>
            </h2>

            <p className="prizes-lead-paragraph">
              Top ideas. Bigger dreams. Exciting rewards. Compete for ₹3,50,000+ in total rewards,
              lucrative cash pools, exclusive trophies, and direct partner access.
            </p>
          </div>

          {/* Authentic Retro Sticky Note with Scotch Tape */}
          <div className="prizes-sticky-note-bay">
            <div className="retro-sticky-note" aria-hidden="true">
              <div className="sticky-scotch-tape" />
              <p className="sticky-title">YOUR</p>
              <p className="sticky-title">IDEA</p>
              <p className="sticky-title">COULD</p>
              <p className="sticky-highlight">BE NEXT! ✦</p>
              <span className="sticky-sub">DREAM • BUILD • WIN</span>
            </div>
          </div>
        </div>

        {/* ── 3 MAIN PODIUM CARDS (EDGE-TO-EDGE EXPANSIVE GRID) ─────── */}
        <div className="prizes-cards-container">
          {MAIN_PRIZES.map((prize, idx) => (
            <div
              key={prize.rank}
              className={`fullscreen-prize-card card-tier-${prize.rank}`}
            >
              {/* Card Window Titlebar */}
              <div className="card-window-topbar">
                <span className="card-status-badge">{prize.status}</span>
                <div className="card-window-btns" aria-hidden="true">
                  <span className="win-btn">_</span>
                  <span className="win-btn">□</span>
                  <span className="win-btn">✕</span>
                </div>
              </div>

              {/* Trophy Bay */}
              <div className="card-trophy-pedestal">
                <RetroTrophy rank={prize.rank} />
              </div>

              {/* Rank / Title */}
              <div className="card-rank-wrap">
                <span className="card-rank-tier">{prize.subtitle}</span>
                <h3 className="card-rank-heading">{prize.title}</h3>
              </div>

              {/* Digital CRT Odometer Box */}
              <div className="card-crt-display">
                <span className="crt-display-val">
                  {counters[idx] > 0
                    ? formatNumberINR(counters[idx], prize.amount)
                    : prize.formatted}
                </span>
                <span className="crt-currency-code">INR / CASH POOL</span>
              </div>

              {/* Perks Checklist */}
              <ul className="card-perks-list">
                {prize.perks.map((perk, pIdx) => (
                  <li key={pIdx} className="card-perk-item">
                    <span className="perk-bullet">★</span>
                    <span className="perk-text">{perk}</span>
                  </li>
                ))}
              </ul>

              {/* Card Bottom Plate */}
              <div className="card-bottom-plate">
                <span className="card-sys-code">{prize.code}</span>
                <span className="card-tier-label">RANK 0{prize.rank}</span>
              </div>
            </div>
          ))}
        </div>

        {/* ── SPECIAL TRACK BOUNTIES SHELF ──────────────────────────── */}
        <div className="special-bounties-shelf">
          <div className="shelf-header-bar">
            <div className="shelf-title-wrap">
              <span className="shelf-glyph">◆</span>
              <span className="shelf-heading">SPECIAL CATEGORY BOUNTIES &amp; CITATIONS</span>
            </div>
            <span className="shelf-meta-tag">// ₹50,000 DEDICATED TRACK POOL</span>
          </div>

          <div className="special-bounties-grid">
            {SPECIAL_BOUNTIES.map((bounty, bIdx) => (
              <div key={bIdx} className="special-bounty-cartridge">
                <div className="bounty-cartridge-top">
                  <span className="bounty-tag">{bounty.tag}</span>
                  <span className="bounty-icon">{bounty.icon}</span>
                </div>
                <h4 className="bounty-name">{bounty.name}</h4>
                <div className="bounty-amount-badge">{bounty.amount}</div>
                <p className="bounty-perk-desc">{bounty.perk}</p>
              </div>
            ))}
          </div>
        </div>

        {/* ── PARTICIPATION PERKS FULL-WIDTH TICKER ─────────────────── */}
        <div className="prizes-participation-plate">
          <div className="plate-badge-pill">EVERY PARTICIPANT GETS</div>
          <div className="plate-perks-row">
            <div className="participant-perk-chip">
              <span className="chip-bullet">✓</span>
              <span>Official IEEE CS Certificate</span>
            </div>
            <div className="participant-perk-chip">
              <span className="chip-bullet">✓</span>
              <span>Exclusive Starter Kit &amp; Swag</span>
            </div>
            <div className="participant-perk-chip">
              <span className="chip-bullet">✓</span>
              <span>Cloud &amp; API Credits Bundle</span>
            </div>
            <div className="participant-perk-chip">
              <span className="chip-bullet">✓</span>
              <span>1-on-1 Mentor Checkpoints</span>
            </div>
            <div className="participant-perk-chip">
              <span className="chip-bullet">✓</span>
              <span>Networking &amp; Internship Access</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
