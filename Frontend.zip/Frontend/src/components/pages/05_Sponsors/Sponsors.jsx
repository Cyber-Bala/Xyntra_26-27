import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import './Sponsors.css'
import ieeeCsLogo from '../../../assets/logos/ieee_cs_logo.png'
import recLogo from '../../../assets/logos/rec_logo.png'

gsap.registerPlugin(ScrollTrigger)

const TITLE_PARTNERS = [
  {
    name: 'IEEE Computer Society',
    role: 'Technical Sponsor & Student Chapter',
    code: 'STU-CH-01 // TECHNICAL ALLIANCE',
    description: 'Empowering the next generation of computing professionals, fostering open technological innovation and peer collaboration.',
    logo: ieeeCsLogo,
    badge: 'TECHNICAL SPONSOR',
  },
  {
    name: 'Rajalakshmi Engineering College',
    role: 'Host Institution & Campus Venue',
    code: 'REC-CAMPUS-26 // HOST ORG',
    description: 'Premier engineering institution providing state-of-the-art laboratory infrastructure, computational facilities, and mentorship.',
    logo: recLogo,
    badge: 'HOST INSTITUTION',
  },
]

const STRATEGIC_SPONSORS = [
  { name: 'Microsoft', tag: 'MSFT.DEV', domain: 'Azure & AI Tools', tier: 'PLATINUM' },
  { name: 'Google Cloud', tag: 'GOOG.CLOUD', domain: 'Compute & Cloud AI', tier: 'PLATINUM' },
  { name: 'AWS', tag: 'AMZN.AWS', domain: 'Cloud & Infrastructure', tier: 'GOLD' },
  { name: 'Intel', tag: 'INTC.CORE', domain: 'Hardware & Edge AI', tier: 'GOLD' },
  { name: 'DELL Technologies', tag: 'DELL.SYS', domain: 'Workstations & Systems', tier: 'GOLD' },
  { name: 'GitHub', tag: 'OCTO.REPO', domain: 'Developer Suite & CI/CD', tier: 'GOLD' },
]

const ECOSYSTEM_PARTNERS = [
  'CloudScale Global',
  'DevMatrix Labs',
  'NeuralForge AI',
  'BlockBridge Protocol',
  'CyberQuest Org',
  'OpenCore Systems',
  'ByteForge Matrix',
  'Polygon Guild',
  'Devfolio Network',
  'Hack2Skill Community',
]

export default function Sponsors({ onNavigate }) {
  const sectionRef = useRef(null)

  useEffect(() => {
    const sect = sectionRef.current
    if (!sect) return undefined

    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.sponsors-hero-block',
        { autoAlpha: 0, y: 24 },
        {
          autoAlpha: 1,
          y: 0,
          duration: 0.7,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sect,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          },
        }
      )

      gsap.fromTo(
        '.title-partner-card',
        { autoAlpha: 0, y: 30 },
        {
          autoAlpha: 1,
          y: 0,
          duration: 0.65,
          stagger: 0.15,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: '.title-partners-dual-grid',
            start: 'top 88%',
            toggleActions: 'play none none reverse',
          },
        }
      )

      gsap.fromTo(
        '.sponsor-cartridge-module',
        { autoAlpha: 0, scale: 0.96 },
        {
          autoAlpha: 1,
          scale: 1,
          duration: 0.5,
          stagger: 0.08,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: '.sponsors-cartridge-grid',
            start: 'top 90%',
            toggleActions: 'play none none reverse',
          },
        }
      )
    }, sect)

    return () => ctx.revert()
  }, [])

  return (
    <section ref={sectionRef} className="retro-sponsors-fullscreen-section" id="sponsors">
      {/* Main Expansive Fullwidth Container */}
      <div className="sponsors-fullwidth-wrapper">
        {/* ── HEADER BLOCK ─────────────────────────────────────────── */}
        <div className="sponsors-hero-block">
          <div className="sponsors-headline-column">
            <div className="section-flow-eyebrow">
              <span className="flow-num">04</span>
              <span className="flow-dash">—</span>
              <span className="flow-label">SPONSORS &amp; PATRONS</span>
            </div>

            <h2 className="sponsors-main-title">
              POWERED BY <br />
              <span className="sponsors-title-amber">OUR ALLIANCES.</span>
            </h2>

            <p className="sponsors-lead-paragraph">
              Joining forces with leading technology innovators, academic patrons, and industry titans
              to deliver a transformative 24-hour hackathon experience.
            </p>
          </div>

          {/* Retro Sticky Note */}
          <div className="sponsors-sticky-bay">
            <div className="sponsors-sticky-note" aria-hidden="true">
              <div className="sponsors-tape-strip" />
              <p className="sp-note-text">WANT TO</p>
              <p className="sp-note-text">SPONSOR?</p>
              <p className="sp-note-highlight">TALK TO US ✦</p>
              <span className="sp-note-email">sponsor@xyntra.org</span>
            </div>
          </div>
        </div>

        {/* ── DUAL TITLE PARTNERS & HOST INSTITUTIONS ──────────────── */}
        <div className="title-partners-dual-grid">
          {TITLE_PARTNERS.map((partner) => (
            <div key={partner.name} className="title-partner-card">
              <div className="partner-card-header">
                <span className="partner-badge-tag">{partner.badge}</span>
                <span className="partner-serial-tag">{partner.code}</span>
              </div>

              <div className="partner-content-row">
                <div className="partner-logo-bay">
                  <img
                    src={partner.logo}
                    alt={partner.name}
                    className="partner-logo-graphic"
                    loading="lazy"
                  />
                </div>

                <div className="partner-info-bay">
                  <h3 className="partner-name-text">{partner.name}</h3>
                  <span className="partner-role-text">{partner.role}</span>
                  <p className="partner-desc-text">{partner.description}</p>
                </div>
              </div>

              <div className="partner-card-footer">
                <span className="partner-verified-stamp">● VERIFIED ALLIANCE</span>
                <span className="partner-status-code">DOC: IEEE-REC-2026</span>
              </div>
            </div>
          ))}
        </div>

        {/* ── STRATEGIC TECH PARTNERS CARTRIDGES ───────────────────── */}
        <div className="sponsors-cartridge-shelf">
          <div className="cartridge-shelf-titlebar">
            <div className="shelf-title-left">
              <span className="shelf-decor-bullet">■</span>
              <span className="shelf-title-label">STRATEGIC TECHNOLOGY SPONSORS</span>
            </div>
            <span className="shelf-tier-indicator">// CLOUD • COMPUTE • TOOLS</span>
          </div>

          <div className="sponsors-cartridge-grid">
            {STRATEGIC_SPONSORS.map((sp) => (
              <div key={sp.name} className="sponsor-cartridge-module">
                <div className="cartridge-pin-strip" aria-hidden="true">
                  <span className="pin" />
                  <span className="pin" />
                  <span className="pin" />
                  <span className="pin" />
                </div>
                <div className="cartridge-inner-plate">
                  <span className="cartridge-code-text">{sp.tag}</span>
                  <h4 className="cartridge-brand-name">{sp.name}</h4>
                  <span className="cartridge-domain-text">{sp.domain}</span>
                </div>
                <div className="cartridge-tier-badge">{sp.tier}</div>
              </div>
            ))}
          </div>
        </div>

        {/* ── ECOSYSTEM & COMMUNITY TICKER ─────────────────────────── */}
        <div className="sponsors-ticker-strip-enclosure">
          <div className="ticker-label-lead">
            <span className="pulse-amber-dot" />
            <span>ECOSYSTEM PARTNERS</span>
          </div>

          <div className="ticker-viewport" aria-label="Ecosystem Partners Ticker">
            <div className="ticker-continuous-track">
              {[0, 1].map((copyIndex) => (
                <div
                  key={copyIndex}
                  className="ticker-repeat-set"
                  aria-hidden={copyIndex === 1}
                >
                  {ECOSYSTEM_PARTNERS.map((name, i) => (
                    <span key={`${copyIndex}-${i}`} className="ticker-token-item">
                      <span className="ticker-token-diamond">◆</span>
                      <span className="ticker-token-name">{name}</span>
                    </span>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* ── SPONSOR CALL TO ACTION BAR ───────────────────────────── */}
        <div className="sponsors-cta-console">
          <div className="cta-left-copy">
            <h4 className="cta-heading">PARTNER WITH XYNTRA 26-27</h4>
            <p className="cta-sub">
              Access 500+ elite engineers, student researchers, and developers. Sponsor tracks, recruit talent, and mentor breakthroughs.
            </p>
          </div>
          <div className="cta-actions-cluster">
            <a
              href="mailto:sponsor@xyntra.org"
              className="retro-sponsor-btn"
              aria-label="Contact Sponsorship Team"
            >
              <span>BECOME A SPONSOR</span>
              <span className="btn-arrow" aria-hidden="true">→</span>
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
