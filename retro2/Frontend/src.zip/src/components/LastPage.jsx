import { WebGLLiquid } from "@/components/ui/webgl-liquid";

import Faq from "./FAQ";
import Contact from "./Contact";
import Footer from "./Footer";

import "../styles/last-page.css";

export default function LastPage() {
  return (
    <div className="last-page">

      {/* WebGL background */}
      <div className="last-page-bg">
        <WebGLLiquid />
      </div>

      {/* Actual page content */}
      <main className="last-page-content">
        <Faq />
        <Contact />
        <Footer />
      </main>

    </div>
  );
}