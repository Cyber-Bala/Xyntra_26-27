import "../styles/Rules.css";

import useReveal from "../hooks/useReveal";

const rules = [
  {
    title: "Respect the Arena",
    text:
      "Treat every participant, organizer and member of the community with respect.",
  },
  {
    title: "Play Fair",
    text:
      "Do not use unauthorized tools, exploits or methods that provide an unfair advantage.",
  },
  {
    title: "Follow the Challenge Rules",
    text:
      "Each challenge may have additional rules. Read the instructions before beginning.",
  },
  {
    title: "Respect the Time Limit",
    text:
      "Submit your work before the competition deadline.",
  },
  {
    title: "Organizer Decision",
    text:
      "Decisions made by the organizers regarding disputes and rule violations are final.",
  },
];

function AnimatedRule({ rule, index }) {
  const ref = useReveal({
    threshold: 0.2,
  });

  return (
    <div
      ref={ref}
      className="rule reveal"
      style={{
        transitionDelay: `${index * 100}ms`,
      }}
    >
      <span className="rule-number">
        {String(index + 1).padStart(2, "0")}
      </span>

      <div>
        <h2>{rule.title}</h2>

        <p>{rule.text}</p>
      </div>
    </div>
  );
}

export default function Rules() {
  const headingRef = useReveal({
    threshold: 0.3,
  });

  const introRef = useReveal({
    threshold: 0.2,
  });

  return (
    <section className="rules" id="rules">

      <div className="rules-container">

        <p className="section-label">
          BEFORE YOU ENTER
        </p>

        <h1
          ref={headingRef}
          className="rules-title reveal-scale"
        >
          RULES <span>&</span> REGULATIONS
        </h1>

        <p
          ref={introRef}
          className="rules-intro reveal"
        >
          Read carefully before entering the gates.
          Every competitor is expected to understand
          and follow these rules.
        </p>

        <div className="rules-list">
          {rules.map((rule, index) => (
            <AnimatedRule
              key={rule.title}
              rule={rule}
              index={index}
            />
          ))}
        </div>

      </div>

    </section>
  );
}