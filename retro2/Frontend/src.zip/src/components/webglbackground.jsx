import { useEffect, useRef } from "react";
import "../styles/WebGLBackground.css";

export default function WebGLBackground() {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const gl = canvas.getContext("webgl");

    if (!gl) {
      console.warn("WebGL is not supported.");
      return;
    }

    const vertexShaderSource = `
      attribute vec2 position;

      void main() {
        gl_Position = vec4(position, 0.0, 1.0);
      }
    `;

    const fragmentShaderSource = `
      precision highp float;

      uniform float u_time;
      uniform vec2 u_resolution;
      uniform vec2 u_mouse;

      float hash(vec2 p) {
        p = fract(p * vec2(123.34, 456.21));
        p += dot(p, p + 45.32);
        return fract(p.x * p.y);
      }

      float noise(vec2 p) {
        vec2 i = floor(p);
        vec2 f = fract(p);

        f = f * f * (3.0 - 2.0 * f);

        return mix(
          mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),
          mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x),
          f.y
        );
      }

      void main() {
        vec2 uv = gl_FragCoord.xy / u_resolution.xy;

        float aspect = u_resolution.x / u_resolution.y;

        vec2 p = uv;
        p.x *= aspect;

        vec2 mouse = u_mouse;
        mouse.x *= aspect;

        float t = u_time * 0.12;

        // Slow atmospheric movement
        float n1 = noise(p * 2.5 + vec2(t, -t * 0.7));
        float n2 = noise(p * 5.0 - vec2(t * 0.4, t));

        float energy = n1 * 0.65 + n2 * 0.35;

        // Moving diagonal energy field
        float diagonal = sin(
          p.x * 2.0 -
          p.y * 1.7 +
          u_time * 0.18
        );

        diagonal = smoothstep(
          0.55,
          1.0,
          diagonal
        );

        // Mouse influence
        float mouseDistance = distance(p, mouse);
        float mouseGlow = exp(-mouseDistance * 2.8);

        // Dark base
        vec3 color = vec3(0.008, 0.012, 0.016);

        // Atmospheric red/orange energy
        color += vec3(
          0.18,
          0.035,
          0.012
        ) * energy * 0.7;

        color += vec3(
          0.28,
          0.055,
          0.015
        ) * diagonal * 0.18;

        color += vec3(
          0.45,
          0.08,
          0.025
        ) * mouseGlow * 0.08;

        // Vignette
        vec2 center = uv - 0.5;
        float vignette = 1.0 - dot(center, center) * 1.35;

        color *= vignette;

        // Very subtle scanline texture
        float scan = sin(gl_FragCoord.y * 0.8) * 0.008;
        color += scan;

        gl_FragColor = vec4(color, 1.0);
      }
    `;

    function createShader(type, source) {
      const shader = gl.createShader(type);

      gl.shaderSource(shader, source);
      gl.compileShader(shader);

      if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
        console.error(gl.getShaderInfoLog(shader));
        gl.deleteShader(shader);
        return null;
      }

      return shader;
    }

    const vertexShader = createShader(
      gl.VERTEX_SHADER,
      vertexShaderSource
    );

    const fragmentShader = createShader(
      gl.FRAGMENT_SHADER,
      fragmentShaderSource
    );

    if (!vertexShader || !fragmentShader) return;

    const program = gl.createProgram();

    gl.attachShader(program, vertexShader);
    gl.attachShader(program, fragmentShader);
    gl.linkProgram(program);

    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
      console.error(gl.getProgramInfoLog(program));
      return;
    }

    gl.useProgram(program);

    const vertices = new Float32Array([
      -1, -1,
       1, -1,
      -1,  1,

      -1,  1,
       1, -1,
       1,  1,
    ]);

    const buffer = gl.createBuffer();

    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.bufferData(
      gl.ARRAY_BUFFER,
      vertices,
      gl.STATIC_DRAW
    );

    const positionLocation = gl.getAttribLocation(
      program,
      "position"
    );

    gl.enableVertexAttribArray(positionLocation);

    gl.vertexAttribPointer(
      positionLocation,
      2,
      gl.FLOAT,
      false,
      0,
      0
    );

    const timeLocation = gl.getUniformLocation(
      program,
      "u_time"
    );

    const resolutionLocation = gl.getUniformLocation(
      program,
      "u_resolution"
    );

    const mouseLocation = gl.getUniformLocation(
      program,
      "u_mouse"
    );

    const mouse = {
      x: 0.5,
      y: 0.5,
    };

    function resize() {
      const dpr = Math.min(window.devicePixelRatio, 2);

      canvas.width = window.innerWidth * dpr;
      canvas.height = window.innerHeight * dpr;

      canvas.style.width = `${window.innerWidth}px`;
      canvas.style.height = `${window.innerHeight}px`;

      gl.viewport(
        0,
        0,
        canvas.width,
        canvas.height
      );
    }

    function handleMouseMove(event) {
      mouse.x = event.clientX / window.innerWidth;
      mouse.y = 1.0 - event.clientY / window.innerHeight;
    }

    window.addEventListener("resize", resize);
    window.addEventListener("mousemove", handleMouseMove);

    resize();

    let animationFrame;

    function render(time) {
      gl.clearColor(0, 0, 0, 1);
      gl.clear(gl.COLOR_BUFFER_BIT);

      gl.useProgram(program);

      gl.uniform1f(
        timeLocation,
        time * 0.001
      );

      gl.uniform2f(
        resolutionLocation,
        canvas.width,
        canvas.height
      );

      gl.uniform2f(
        mouseLocation,
        mouse.x * (canvas.width / canvas.height),
        mouse.y
      );

      gl.drawArrays(
        gl.TRIANGLES,
        0,
        6
      );

      animationFrame = requestAnimationFrame(render);
    }

    animationFrame = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationFrame);

      window.removeEventListener(
        "resize",
        resize
      );

      window.removeEventListener(
        "mousemove",
        handleMouseMove
      );

      gl.deleteProgram(program);
      gl.deleteShader(vertexShader);
      gl.deleteShader(fragmentShader);
      gl.deleteBuffer(buffer);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="webgl-background"
    />
  );
}