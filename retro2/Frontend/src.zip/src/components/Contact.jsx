import useReveal from "../hooks/useReveal";

import "../styles/Contact.css";

export default function Contact() {
  const headingRef = useReveal({
    threshold: 0.2,
  });

  const contentRef = useReveal({
    threshold: 0.15,
  });

  return (
    <section
      className="contact"
      id="contact"
    >

      <div className="contact-container">

        <div
          ref={headingRef}
          className="contact-heading reveal-left"
        >

          <p className="section-label">
            NEED ASSISTANCE?
          </p>

          <h2>
            CONTACT
            <span>
              THE GATEKEEPERS
            </span>
          </h2>

        </div>


        <div
          ref={contentRef}
          className="contact-content reveal"
        >

          <p>
            Have a question about the
            competition, rules or
            registration? Reach out to
            the organizers.
          </p>


          <div className="contact-links">

            <a href="mailto:hello@example.com">
              <span>EMAIL</span>
              hello@example.com
            </a>

            <a href="#">
              <span>COMMUNITY</span>
              Discord
            </a>

            <a href="#">
              <span>SOCIAL</span>
              Instagram
            </a>

          </div>

        </div>

      </div>

    </section>
  );
}