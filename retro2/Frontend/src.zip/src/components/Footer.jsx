import useReveal from "../hooks/useReveal";

import "../styles/Footer.css";

export default function Footer() {
  const ref = useReveal({
    threshold: 0.2,
  });

  return (
    <footer
      ref={ref}
      className="footer reveal"
    >

      <div className="footer-container">

        <p>
          © 2026 THE GATES
        </p>

        <p>
          ENTER. BUILD. CONQUER.
        </p>

      </div>

    </footer>
  );
}