import { useState } from "react";

import useReveal from "../hooks/useReveal";

import "../styles/FAQ.css";

const questions = [
  {
    question: "Who can enter the gates?",
    answer:
      "Anyone who meets the eligibility requirements can participate.",
  },
  {
    question:
      "Can I compete alone, or do I need a team?",
    answer:
      "You can participate individually unless a particular challenge specifies a team requirement.",
  },
  {
    question: "What if I arrive without a plan?",
    answer:
      "Read the challenge carefully, understand the objective, and work through the problem step by step.",
  },
  {
    question:
      "What happens if my build is judged unworthy?",
    answer:
      "The organizers will review the submission according to the published rules and judging criteria.",
  },
  {
    question:
      "Is there a prize for those who reach the walls?",
    answer:
      "Prize information will be announced by the organizers.",
  },
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState(null);

  const headingRef = useReveal({
    threshold: 0.25,
  });

  function toggleQuestion(index) {
    setOpenIndex(
      openIndex === index
        ? null
        : index
    );
  }

  return (
    <section className="faq" id="faq">

      <div className="faq-container">

        <p className="section-label">
          BEFORE YOU CROSS THE WALLS
        </p>

        <h2
          ref={headingRef}
          className="faq-title reveal"
        >
          QUESTIONS ASKED
          <span> AT THE GATES</span>
        </h2>

        <div className="faq-list">

          {questions.map((item, index) => {

            const isOpen =
              openIndex === index;

            return (
              <div
                className={`faq-item ${
                  isOpen ? "open" : ""
                }`}
                key={item.question}
              >

                <button
                  className="faq-question"
                  onClick={() =>
                    toggleQuestion(index)
                  }
                  aria-expanded={isOpen}
                >
                  <span>
                    {item.question}
                  </span>

                  <span
                    className="faq-icon"
                  >
                    +
                  </span>
                </button>

                <div className="faq-answer-wrapper">
                  <div className="faq-answer">
                    <p>
                      {item.answer}
                    </p>
                  </div>
                </div>

              </div>
            );
          })}

        </div>

      </div>

    </section>
  );
}