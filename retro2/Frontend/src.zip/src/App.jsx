import Rules from "./components/Rules";
import FAQ from "./components/FAQ";
import Contact from "./components/Contact";
import Footer from "./components/Footer";

import SmoothScroll from "./components/SmoothScroll";
import WebGLBackground from "./components/WebGLBackground";
import PageAnimations from "./components/pageanimation";

import "./styles/App.css";

function App() {
  return (
    <SmoothScroll>

      <div className="app">

        <WebGLBackground />

        <PageAnimations />

        <main>
          <Rules />
          <FAQ />
          <Contact />
        </main>

        <Footer />

      </div>

    </SmoothScroll>
  );
}

export default App;