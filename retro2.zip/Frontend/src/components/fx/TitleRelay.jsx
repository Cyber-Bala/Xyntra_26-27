import { useEffect } from 'react'

/*
  TitleRelay
  ----------
  One swarm of square particles that travels down the page from big heading to big heading:

     XYNTRA  ──disintegrates──►  dust  ──assembles──►  BUILD WHAT'S NEXT.  ──►  dust  ──►  CHOOSE YOUR WORLD.  ...

  Everything is driven by scroll position (scrub), so it reverses when you scroll back up.
  The cursor / finger scatters the swarm wherever it is, and it springs back.

  The headings are every h1/h2 >= 30px inside .main-content-view, in page order.
  The real DOM text is only hidden while the swarm is drawing that heading (so SEO / screen readers keep it).
  To exclude a heading from the relay add  data-fx="off"  to it.

  TUNING (all in one place):
*/
const SELECTOR = '.main-content-view h1, .main-content-view h2'
const MIN_FONT = 30
const MAX_N = 7000            // particle budget
const DISSOLVE_START = 0.4    // when the heading's BOTTOM edge rises above this fraction of the viewport height it starts to disintegrate
const DISSOLVE_LEN = 0.45     // ...and how much scrolling the disintegration takes
const ASSEMBLE_START = 1.15   // next heading's centre position where the swarm starts flying to it
const ASSEMBLE_LEN = 0.55     // ...and how much scrolling the assembly takes
const DUST_ALPHA = 0.4        // opacity of the swarm while it hangs between headings
const LEVELS = ['#f6ebcb', '#f4e1ae', '#f3cf80', '#f2a93b'] // cream -> amber

const clamp = (v, a = 0, b = 1) => Math.min(Math.max(v, a), b)
const ease = (t) => t * t * (3 - 2 * t)
const lerp = (a, b, t) => a + (b - a) * t

/* Paint the heading's real glyphs offscreen (exact browser layout) and turn the pixels into points. */
function sampleHeading(el) {
  const rect = el.getBoundingClientRect()
  const cs = getComputedStyle(el)
  const size = parseFloat(cs.fontSize)
  if (rect.width < 40 || rect.height < 20 || size < MIN_FONT) return null

  const PAD = 8
  const W = Math.ceil(rect.width + PAD * 2)
  const H = Math.ceil(rect.height + PAD * 2)
  const off = document.createElement('canvas')
  off.width = W; off.height = H
  const octx = off.getContext('2d', { willReadFrequently: true })
  const grad = octx.createLinearGradient(0, PAD, 0, PAD + rect.height)
  grad.addColorStop(0, '#f6ebcb')
  grad.addColorStop(1, '#f2a93b')
  octx.fillStyle = grad
  octx.textBaseline = 'alphabetic'

  const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT)
  const range = document.createRange()
  let node
  while ((node = walker.nextNode())) {
    if (!node.nodeValue.trim()) continue
    const pcs = getComputedStyle(node.parentElement)
    octx.font = `${pcs.fontStyle} ${pcs.fontWeight} ${pcs.fontSize} ${pcs.fontFamily}`
    const asc = octx.measureText('M').fontBoundingBoxAscent || parseFloat(pcs.fontSize) * 0.9
    const upper = pcs.textTransform === 'uppercase'
    const text = node.nodeValue
    for (let i = 0; i < text.length; i++) {
      if (!text[i].trim()) continue
      range.setStart(node, i)
      range.setEnd(node, i + 1)
      const r = range.getClientRects()[0]
      if (!r || !r.width) continue
      octx.fillText(upper ? text[i].toUpperCase() : text[i], r.left - rect.left + PAD, r.top - rect.top + PAD + asc)
    }
  }

  let gap = size >= 160 ? 4 : size >= 80 ? 3 : 2
  let pts
  for (;;) {
    pts = []
    const data = octx.getImageData(0, 0, W, H).data
    for (let y = 0; y < H; y += gap) {
      for (let x = 0; x < W; x += gap) {
        const idx = ((y + (gap >> 1)) * W + x + (gap >> 1)) * 4
        if (data[idx + 3] > 110) {
          const lvl = Math.max(0, Math.min(3, Math.floor((235 - data[idx + 1]) / 17)))
          pts.push(x - PAD, y - PAD, lvl)
        }
      }
    }
    if (pts.length / 3 <= MAX_N) break
    gap += 1
  }
  const n = pts.length / 3
  if (!n) return null
  const X = new Float32Array(n), Y = new Float32Array(n), L = new Uint8Array(n)
  for (let i = 0; i < n; i++) { X[i] = pts[i * 3]; Y[i] = pts[i * 3 + 1]; L[i] = pts[i * 3 + 2] }
  return { el, gap, n, X, Y, L }
}

class Relay {
  constructor() {
    this.canvas = document.createElement('canvas')
    this.canvas.className = 'relay-canvas'
    this.canvas.setAttribute('aria-hidden', 'true')
    document.body.appendChild(this.canvas)
    this.ctx = this.canvas.getContext('2d')
    this.heads = []
    this.N = 0
    this.pointer = { x: -9999, y: -9999, t: 0 }
    this.raf = 0
    this.lastKey = ''
    this.t0 = performance.now()
    this.resize()
    this.tick = this.tick.bind(this)
    this.raf = requestAnimationFrame(this.tick)
  }

  resize() {
    this.dpr = Math.min(window.devicePixelRatio || 1, 1.5)
    this.vw = window.innerWidth
    this.vh = window.innerHeight
    this.canvas.width = this.vw * this.dpr
    this.canvas.height = this.vh * this.dpr
    this.ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0)
    this.lastKey = ''
  }

  /* (re)sample every heading and map them onto the same N particles */
  build() {
    const list = [...document.querySelectorAll(SELECTOR)].filter((el) => el.dataset.fx !== 'off')
    this.heads.forEach((h) => h.el.classList.remove('pt-live'))
    const sampled = list.map(sampleHeading).filter(Boolean)
    this.sig = sampled.map((h) => h.el)
    this.N = Math.min(MAX_N, sampled.reduce((m, h) => Math.max(m, h.n), 0))
    const N = this.N
    sampled.forEach((h) => {
      const perm = Array.from({ length: h.n }, (_, i) => i)
      for (let i = perm.length - 1; i > 0; i--) { const j = (Math.random() * (i + 1)) | 0; [perm[i], perm[j]] = [perm[j], perm[i]] }
      h.hx = new Float32Array(N); h.hy = new Float32Array(N); h.hl = new Uint8Array(N)
      for (let j = 0; j < N; j++) { const k = perm[j % h.n]; h.hx[j] = h.X[k]; h.hy[j] = h.Y[k]; h.hl[j] = h.L[k] }
    })
    this.heads = sampled
    this.ox = new Float32Array(N); this.oy = new Float32Array(N)
    this.vx = new Float32Array(N); this.vy = new Float32Array(N)
    this.th = new Float32Array(N); this.rho = new Float32Array(N); this.sr = new Float32Array(N); this.born = new Float32Array(N)
    const now = performance.now()
    for (let j = 0; j < N; j++) {
      this.th[j] = Math.random() * Math.PI * 2
      this.rho[j] = Math.sqrt(Math.random())
      this.sr[j] = 30 + Math.random() * 130
      this.born[j] = now + Math.random() * 500
    }
    this.introUntil = now + 1500
    this.lastKey = ''
  }

  needsRebuild() {
    const list = [...document.querySelectorAll(SELECTOR)].filter((el) => el.dataset.fx !== 'off')
    const ok = list.filter((el) => {
      const r = el.getBoundingClientRect()
      return r.width >= 40 && r.height >= 20 && parseFloat(getComputedStyle(el).fontSize) >= MIN_FONT
    })
    if (ok.length !== this.sig?.length) return true
    return ok.some((el, i) => el !== this.sig[i])
  }

  setLive(h, on) {
    if (!h) return
    if (on && !h.el.classList.contains('pt-live')) h.el.classList.add('pt-live')
    if (!on && h.el.classList.contains('pt-live')) h.el.classList.remove('pt-live')
  }

  tick(now) {
    this.raf = requestAnimationFrame(this.tick)
    const heads = this.heads
    const M = heads.length
    if (!M || document.hidden) return
    const { vw, vh, ctx, N } = this

    const rects = heads.map((h) => h.el.getBoundingClientRect())
    const cs = rects.map((r) => r.top + r.height / 2)

    // which transition are we in?  A = heading the swarm is leaving, B = heading it is flying to
    let k = 0, aB = 0
    if (M > 1) {
      for (k = 0; k < M - 1; k++) {
        aB = clamp((ASSEMBLE_START - cs[k + 1] / vh) / ASSEMBLE_LEN)
        if (aB < 1) break
      }
      if (k >= M - 1) { k = M - 2; aB = 1 }
    }
    const A = k, B = Math.min(k + 1, M - 1)
    // never dissolve a heading that is still at its natural resting spot near the top of the page
    const trigger = Math.min(DISSOLVE_START * vh, rects[A].bottom + window.scrollY - 24)
    const dA = M === 1 ? 0 : clamp((trigger - rects[A].bottom) / (DISSOLVE_LEN * vh))
    const e1 = ease(dA), e2 = ease(aB)

    // hide the real text only while the swarm is drawing it
    heads.forEach((h, i) => {
      const hide = (i === A && aB < 1) || (i === B && aB > 0) || (M === 1)
      this.setLive(h, hide)
    })

    // skip work when nothing changes
    const pointerRecent = now - this.pointer.t < 1400
    const introActive = now < this.introUntil
    const dusty = e1 > 0 && e2 < 1
    const key = `${rects[A].top | 0}|${rects[A].left | 0}|${rects[B].top | 0}|${dA.toFixed(3)}|${aB.toFixed(3)}|${vw}|${vh}`
    if (!pointerRecent && !introActive && !dusty && !this.energy && key === this.lastKey) return
    this.lastKey = key

    const HA = heads[A], HB = heads[B]
    const rA = rects[A], rB = rects[B]
    const gapSize = e2 > 0 ? lerp(2.5, HB.gap, e2) : lerp(HA.gap, 2.5, e1)
    const size = Math.max(2, Math.round(gapSize))
    const dustCx = vw * 0.5, dustCy = vh * 0.46
    const RX = vw * 0.30, RY = vh * 0.27
    const tsec = now * 0.00011
    const px = this.pointer.x, py = this.pointer.y
    const R = 110, R2 = R * R
    const { ox, oy, vx, vy, th, rho, sr, born } = this
    let energy = 0

    ctx.clearRect(0, 0, vw, vh)
    ctx.globalAlpha = 1 - (1 - DUST_ALPHA) * e1 * (1 - e2)

    for (let L = 0; L < 4; L++) {
      ctx.fillStyle = LEVELS[L]
      for (let j = 0; j < N; j++) {
        const lvl = e2 >= 0.5 ? HB.hl[j] : HA.hl[j]
        if (lvl !== L) continue

        // 1. leave heading A  2. hang as dust  3. fly into heading B
        const ax = rA.left + HA.hx[j], ay = rA.top + HA.hy[j]
        const ang = th[j] + tsec * (0.5 + rho[j]) * 6
        const dx0 = dustCx + Math.cos(ang) * rho[j] * RX
        const dy0 = dustCy + Math.sin(ang) * rho[j] * RY
        let x = lerp(ax, dx0, e1), y = lerp(ay, dy0, e1)
        const bulge1 = Math.sin(Math.PI * e1) * sr[j]
        x += Math.cos(th[j] * 3) * bulge1; y += Math.sin(th[j] * 3) * bulge1
        if (e2 > 0) {
          const bx = rB.left + HB.hx[j], by = rB.top + HB.hy[j]
          x = lerp(x, bx, e2); y = lerp(y, by, e2)
          const bulge2 = Math.sin(Math.PI * e2) * sr[j]
          x += Math.cos(th[j] * 2 + 1) * bulge2; y += Math.sin(th[j] * 2 + 1) * bulge2
        }

        // page-load assemble-from-dust
        if (introActive) {
          const ti = clamp((now - born[j]) / 900)
          if (ti < 1) {
            const s = ease(ti)
            x = lerp(dustCx + (th[j] - 3.14) * 140, x, s); y = lerp(vh * 0.5 + Math.sin(th[j] * 5) * 220, y, s)
          }
        }

        // cursor disintegration (spring back)
        const ddx = x + ox[j] - px, ddy = y + oy[j] - py
        const d2 = ddx * ddx + ddy * ddy
        if (d2 < R2) {
          const d = Math.sqrt(d2) + 0.01
          const f = (1 - d / R) * (1 - d / R) * 7
          vx[j] += (ddx / d) * f - (ddy / d) * f * 0.55 + (Math.random() - 0.5) * f * 0.9
          vy[j] += (ddy / d) * f + (ddx / d) * f * 0.55 - f * 0.22 + (Math.random() - 0.5) * f * 0.9
        }
        vx[j] = (vx[j] - ox[j] * 0.085) * 0.82
        vy[j] = (vy[j] - oy[j] * 0.085) * 0.82
        ox[j] += vx[j]; oy[j] += vy[j]
        energy += Math.abs(ox[j]) + Math.abs(oy[j])

        const fx = x + ox[j], fy = y + oy[j]
        if (fx < -6 || fx > vw + 6 || fy < -6 || fy > vh + 6) continue
        ctx.fillRect(Math.round(fx), Math.round(fy), size, size)
      }
    }
    ctx.globalAlpha = 1
    this.energy = energy > N * 0.04
  }

  destroy() {
    cancelAnimationFrame(this.raf)
    this.heads.forEach((h) => h.el.classList.remove('pt-live'))
    this.canvas.remove()
  }
}

export default function TitleRelay() {
  useEffect(() => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return undefined
    const relay = new Relay()
    let resizeTimer
    const start = () => relay.build()
    if (document.fonts?.ready) document.fonts.ready.then(start); else start()
    const watch = setInterval(() => { if (relay.needsRebuild()) relay.build() }, 1200)
    const onMove = (e) => { relay.pointer.x = e.clientX; relay.pointer.y = e.clientY; relay.pointer.t = performance.now() }
    const onLeave = () => { relay.pointer.x = -9999; relay.pointer.y = -9999 }
    const onResize = () => { relay.resize(); clearTimeout(resizeTimer); resizeTimer = setTimeout(() => relay.build(), 250) }
    window.addEventListener('pointermove', onMove, { passive: true })
    window.addEventListener('pointerdown', onMove, { passive: true })
    document.addEventListener('pointerleave', onLeave)
    window.addEventListener('resize', onResize)
    return () => {
      clearInterval(watch); clearTimeout(resizeTimer)
      window.removeEventListener('pointermove', onMove)
      window.removeEventListener('pointerdown', onMove)
      document.removeEventListener('pointerleave', onLeave)
      window.removeEventListener('resize', onResize)
      relay.destroy()
    }
  }, [])
  return null
}
